'use strict';
var filters = angular.module('LeapApp.filters', []);
