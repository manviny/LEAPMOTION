'use strict';

angular.module('LeapApp', ['LeapApp.filters', 'LeapApp.services', 'LeapApp.directives', 'LeapApp.controllers']);

