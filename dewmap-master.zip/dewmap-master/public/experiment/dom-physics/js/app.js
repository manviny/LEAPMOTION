'use strict';


// Declare app level module which depends on filters, and services
angular.module('Box2dDom', ['Box2dDom.filters', 'Box2dDom.services', 'Box2dDom.directives', 'Box2dDom.controllers']);


