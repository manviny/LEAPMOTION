'use strict';


// Declare app level module which depends on filters, and services
angular.module('AbstractTech', ['AbstractTech.filters', 'AbstractTech.services', 'AbstractTech.directives', 'AbstractTech.controllers']);


