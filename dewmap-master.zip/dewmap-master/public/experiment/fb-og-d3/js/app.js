'use strict';


// Declare app level module which depends on filters, and services
angular.module('fb-og-d3', ['fb-og-d3.filters', 'fb-og-d3.services', 'fb-og-d3.directives', 'fb-og-d3.controllers']);

