'use strict';

var filters = angular.module('fb-og-d3.filters', []);

