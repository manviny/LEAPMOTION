'use strict';


// Declare app level module which depends on filters, and services
angular.module('pie-menu-d3', ['pie-menu-d3.filters', 'pie-menu-d3.services', 'pie-menu-d3.directives', 'pie-menu-d3.controllers']);

