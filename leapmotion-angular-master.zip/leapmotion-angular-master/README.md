Leap Motion basic example
==================

Small example for the LogN Tech Talk of the Leap Motion hands, tools and fingers with AngularJS to display the data in real-time per frame.



See LEAP Motion presentation [here](http://leap-slides.herokuapp.com/)

See live example [here](http://leap-slides.herokuapp.com/basic-example/)
